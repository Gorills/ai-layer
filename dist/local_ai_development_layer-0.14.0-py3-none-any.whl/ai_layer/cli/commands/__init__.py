"""CLI command registration modules."""
