"""Focused MCP tool adapters."""
