from __future__ import annotations

from ai_layer.db.models import Task, TaskStage
from ai_layer.domain.agent_contract import ENVELOPE_WORKER
from ai_layer.tasks.contracts import _stage_agent_policy
from ai_layer.tasks.state_store import task_key


def _worker_role_contract(stage_kind: str) -> str:
    if stage_kind in {"implement", "fix"}:
        return "This delegated worker is the only actor allowed to perform repository/external mutations for this stage."
    return "This delegated worker is read-only and must not mutate repository/external state."


def _expertise_contract() -> dict:
    return {
        "routing_owner": "The host agent's native Agent Skills mechanism owns skill relevance and activation. AI Layer does not provide a parallel required/recommended/on-demand plan.",
        "authoritative_content": "When a native skill activates, retrieve the smallest relevant authoritative AI Layer section with skill_get instead of guessing or eagerly loading unrelated domain guidance.",
        "progressive_retrieval": "Prefer an exact section; request full skill content only when targeted sections are insufficient. Host automatic-vs-manual activation is not observable by AI Layer.",
    }


def _knowledge_review_contract(task: Task) -> dict:
    return {
        "source_task_id": str(task.id),
        "tool": "knowledge_list",
        "rule": (
            "DRAFT Project Knowledge exists for this task. Verify each semantic claim against the cited "
            "current repository evidence; a passing review publishes those drafts."
        ),
    }


def _provenance_notice(task: Task) -> str | None:
    if (task.execution_origin or "managed") == "adopted_unmanaged_changes":
        return (
            "Repository changes predate this managed task; review/remediate them without claiming "
            "AI Layer executed the original implementation."
        )
    if int((task.preexisting_changes or {}).get("total") or 0):
        return (
            "This task started from a dirty worktree captured as an immutable baseline. Preserve pre-existing edits. "
            "Managed task delta is measured against that baseline, not Git HEAD. Never stash/reset/restore/commit "
            "pre-existing work merely to satisfy AI Layer workflow."
        )
    return None


def _inline_micro_stage(task: Task, stage: TaskStage) -> bool:
    return (
        stage.kind == "implement"
        and int(task.workflow_version or 1) >= 3
        and not bool(stage.delegation_required)
    )


def _base_contract(task: Task, stage: TaskStage, *, inline_micro: bool) -> dict[str, object]:
    role = (
        "inline_micro_implementer"
        if inline_micro
        else {
            "implement": "implementer",
            "review": "reviewer",
            "fix": "fixer",
            "discovery": "discovery",
        }.get(stage.kind)
    )
    contract: dict[str, object] = {
        "task": task_key(task),
        "stage_id": str(stage.id),
        "stage": stage.kind,
        "role": role,
        "goal": task.goal,
        "acceptance_criteria": list(task.acceptance_criteria or []),
        "constraints": list(task.constraints or []),
        "execution_origin": task.execution_origin or "managed",
        "workflow": {
            "version": int(task.workflow_version or 1),
            "profile": task.workflow_profile or "legacy_standard",
        },
        "risk": {"level": task.risk_level or "normal", "reasons": list(task.risk_reasons or [])},
        "cost_policy": task.cost_policy or "economy",
        "agent_policy": _stage_agent_policy(stage),
        "discovery_result": dict(task.discovery_result or {}),
        "adopted_changes": dict(task.adopted_changes or {}),
        "preexisting_changes": dict(task.preexisting_changes or {}),
        "fresh_subagent_required": not inline_micro,
        "orchestrator_edits_forbidden": not inline_micro,
        "orchestrator_fallback_forbidden": not inline_micro,
        "worker_role_contract": (
            "The top-level actor is temporarily authorized to perform only this bounded MICRO repository edit; "
            "AI Layer validates the resulting diff before completion."
            if inline_micro
            else _worker_role_contract(stage.kind)
        ),
        "task_state_tools_forbidden_for_worker": not inline_micro,
        "return_to_orchestrator": (
            "After the localized edit and focused verification, call task_implementation_complete directly; "
            "no separate worker handoff is required."
            if inline_micro
            else "Return actual stage evidence/results only; the parent records the transition and must never perform or finish this stage on your behalf."
        ),
        "identity_enforcement": (
            "Inline MICRO authority is represented durably by a non-delegated workflow-v3 IMPLEMENT stage; "
            "post-change scope is enforced by the machine-side micro envelope."
            if inline_micro
            else "AI Layer enforces label uniqueness and discovery/reviewer read-only managed-repository identity; the current host protocol does not expose authenticated native-subagent identity, so actor independence is a protocol requirement rather than a cryptographic guarantee."
        ),
        "check_evidence_assurance": (
            "Stage checks are actor-reported evidence unless verification_run supplies AI-Layer-executed evidence."
            if inline_micro
            else "Stage checks are worker-reported evidence. AI Layer requires them but does not independently execute arbitrary reported host commands."
        ),
        "external_action_policy": {
            "verification": "Read-only shell/HTTP/staging observations may be performed and recorded as verification evidence.",
            "mutation": (
                "External mutations are not eligible for inline MICRO completion; declaring one forces escalation."
                if inline_micro
                else "Any external system mutation required by acceptance belongs to the delegated implementer/fixer stage, not the orchestrator, and must be declared in external_actions."
            ),
            "read_only_stages": "Discovery/review may record only verification actions; external mutations are forbidden.",
            "assurance": "AI Layer can audit declared external actions but cannot independently detect mutations made outside its tools/host protocol.",
        },
        "expertise_contract": _expertise_contract(),
    }
    if not inline_micro:
        contract["worker_id_requirement"] = (
            "Use a new stable label for this delegated worker; labels cannot be reused inside one task."
        )
    provenance_notice = _provenance_notice(task)
    if provenance_notice:
        contract["provenance_notice"] = provenance_notice
    return contract


def _discovery_payload() -> dict[str, object]:
    return {
        "repository_mode": "read-only",
        "context_policy": {
            "mode": "isolated_discovery",
            "include": [
                "task goal and constraints",
                "current source/project intelligence",
                "host-selected relevant skill instructions",
                "read-only verification evidence",
            ],
            "exclude": [
                "implementation assumptions presented as facts",
                "full orchestration transcript when isolated context is available",
            ],
        },
        "requirements": [
            "Investigate the actual repository before proposing implementation.",
            "Separate verified facts from hypotheses and risks.",
            "Return a compact proposed plan/acceptance refinements when implementation is warranted.",
            "Do not modify repository files or external state.",
        ],
    }


def _review_payload(
    task: Task,
    stage: TaskStage,
    open_findings: list[dict],
    *,
    knowledge_review_required: bool,
) -> dict[str, object]:
    pending_verification = [
        item for item in open_findings if item.get("status") == "pending_verification"
    ]
    requirements = [
        "Inspect the actual implementation and relevant tests.",
        "Explicitly verify every finding_to_verify against the current repository state and return one verification_results entry per finding id with evidence.",
        "Run appropriate verification checks. If checks may write caches/test artifacts, use the AI Layer review sandbox instead of the canonical repository.",
        "Assess documentation impact from the actual diff. Changes to configuration, setup, deployment, public API, persistence/media, migrations requiring operator action, or runtime processes must update the existing owning docs/examples when such documentation exists; internal-only changes do not require documentation churn.",
    ]
    if knowledge_review_required:
        requirements.append(
            "Call knowledge_list(status=DRAFT, source_task_id=project_knowledge_review.source_task_id) and independently verify the returned Project Knowledge cards; unsupported or incomplete claims are actionable findings."
        )
    requirements.extend(
        [
            "Do not modify repository files.",
            "Return verdict=pass only when no actionable findings remain.",
        ]
    )
    payload: dict[str, object] = {
        "repository_mode": "read-only",
        "review_round": stage.review_round,
        "findings_to_verify": pending_verification,
        "context_policy": {
            "mode": "isolated_review",
            "include": [
                "task goal and acceptance criteria",
                "task constraints",
                "current repository state and diff",
                "relevant project evidence",
                "pending finding IDs requiring verification",
            ],
            "exclude": [
                "implementer/fixer self-assessment",
                "prior reviewer conclusions except pending finding records",
                "parent/orchestrator persuasion or full transcript",
            ],
            "host_requirement": "Start the reviewer from this compact contract plus repository access; do not inject the full orchestration transcript when the host supports isolated subagent context.",
        },
        "requirements": requirements,
    }
    if knowledge_review_required:
        payload["project_knowledge_review"] = _knowledge_review_contract(task)
    return payload


def _fix_payload(stage: TaskStage, open_findings: list[dict]) -> dict[str, object]:
    return {
        "repository_mode": "write",
        "fix_round": stage.fix_round,
        "open_findings": open_findings,
        "requirements": [
            "Address the review findings without broad unrelated changes.",
            "Apply documentation-impact fixes only when the changed external/developer/operator contract requires them; update the existing owning document rather than creating parallel guidance.",
            "If there are no findings, verify that no fix is needed and complete as no_changes_needed.",
        ],
    }


def _implementation_payload(*, inline_micro: bool) -> dict[str, object]:
    requirements = [
        "Implement the task contract completely.",
        "Use knowledge_draft_upsert only when the task explicitly requires creating/updating Project Knowledge; never turn ordinary coding work into automatic documentation generation.",
        "Add or update tests appropriate to the change.",
        "Assess documentation impact: update existing setup/config/deploy/API/storage/migration/runtime documentation or safe examples when the task changes those contracts; do not churn docs for internal-only changes.",
        "Run focused verification before completing the stage.",
    ]
    if inline_micro:
        requirements.insert(
            0,
            "Keep the edit inside the localized MICRO intent. Do not broaden scope merely because repository-write authority is temporarily available.",
        )
    return {
        "repository_mode": "write",
        "execution_mode": "inline_micro" if inline_micro else "delegated",
        "requirements": requirements,
    }


def build_delegation_contract(
    task: Task,
    stage: TaskStage,
    open_findings: list[dict],
    completion_contract: dict,
    *,
    knowledge_review_required: bool = False,
) -> dict:
    inline_micro = _inline_micro_stage(task, stage)
    contract = _base_contract(task, stage, inline_micro=inline_micro)
    if stage.kind == "discovery":
        contract.update(_discovery_payload())
    elif stage.kind == "review":
        contract.update(
            _review_payload(
                task,
                stage,
                open_findings,
                knowledge_review_required=knowledge_review_required,
            )
        )
    elif stage.kind == "fix":
        contract.update(_fix_payload(stage, open_findings))
    else:
        contract.update(_implementation_payload(inline_micro=inline_micro))
    contract["completion_contract"] = completion_contract
    return contract


_WORKER_JOB_KEYS = (
    "task",
    "stage_id",
    "stage",
    "role",
    "goal",
    "acceptance_criteria",
    "constraints",
    "repository_mode",
    "execution_mode",
    "context_policy",
    "requirements",
    "findings_to_verify",
    "open_findings",
    "review_round",
    "fix_round",
    "completion_contract",
    "provenance_notice",
    "project_knowledge_review",
    "discovery_result",
    "agent_policy",
    "workflow",
    "risk",
)


def worker_job_packet(contract: dict | None) -> dict:
    """MCP-facing worker envelope: job fields only, no orchestrator protocol essays."""
    source = dict(contract or {})
    packet: dict[str, object] = {"envelope": ENVELOPE_WORKER}
    for key in _WORKER_JOB_KEYS:
        if key not in source:
            continue
        value = source[key]
        if value is None:
            continue
        packet[key] = value
    return packet
